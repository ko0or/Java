INSERT INTO article(id, title, content) VALUES (1, '첫번째 글', 'data.sql 파일에 의해 자동생성되었습니다. [1]')
INSERT INTO article(id, title, content) VALUES (2, '두번째 글', 'data.sql 파일에 의해 자동생성되었습니다. [2]')
INSERT INTO article(id, title, content) VALUES (3, '세번째 글', 'data.sql 파일에 의해 자동생성되었습니다. [3]')